#!/bin/bash

for D in ./*; do
    if [ -d "$D" ]; then
        cd "$D"
        # Run
        osascript applescript.applescript -b 2>&1 | tee -a applescript_login.html
        mv ~/Desktop/*.png .
        cd ..
    fi
done
