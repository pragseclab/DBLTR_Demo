import time, os, errno, argparse, sys
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, ElementNotVisibleException
from selenium.webdriver.common.by import By
from datetime import datetime
from pyvirtualdisplay import Display
'''
Running over ssh:
    Xvfb :89 -ac -noreset &
    export DISPLAY=:89
'''

username = 'nathan.brown1959@outlook.com'
password = 'zaq1@WSX'
login_url = 'https://www.crunchbase.com/login'
successful_load = 'Products'
successful_login = 'Log Out'
referer = login_url
use_chrome = True
use_firefox = False
use_blink = False
selected_browser = ''

chrome_uagent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
ff_uagent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1"

class Login:
    def __init__(self, username, password, referer, login_url, origin, uagent, csrf_enabled = False):
        self. username = username
        self.password = password
        self.referer = referer
        self.login_url = login_url
        self.origin = origin
        self.uagent = uagent
        self.csrf_enabled = csrf_enabled
        if use_chrome :
            self.filename = 'selenium_chrome_login.html'
            self.imagename = 'selenium_chrome_login.png'
        elif use_firefox :
            self.filename = 'selenium_ff_login.html'
            self.imagename = 'selenium_ff_login.png'
        elif use_blink :
            self.filename = 'selenium_blink_login.html'
            self.imagename = 'selenium_blink_login.png'
        self.driver = None
        self.start_time = None
        self.timeout = 15
        self.set_up()

    def set_up(self):
        self.start_time = datetime.now()
        if use_chrome :
            print "[+] Setting up ChromeDriver"
            options = webdriver.chrome.options.Options()
            options.add_argument("user-agent=" + self.uagent)
            self.driver = webdriver.Chrome(chrome_options=options)
            self.driver.set_page_load_timeout(60)
        elif use_firefox :
            print "[+] Setting up GeckoDriver"
            profile = webdriver.FirefoxProfile()
            profile.set_preference("general.useragent.override", self.uagent)
            self.driver = webdriver.Firefox(profile)
            self.driver.set_page_load_timeout(60)
        elif use_blink :
            from BrowserHandler import BrowserHandler
            browser_handler = BrowserHandler()
            self.driver = browser_handler.get_driver(selected_browser)
            self.driver.set_page_load_timeout(60)
        print "[+] Done."

    def update_filename(self, filename) :
        self.filename = filename

    def update_imagename(self, imagename) :
        self.imagename = imagename

    def update_password(self, password) :
        self.password = password

    def clean_up(self):
        self.driver.close()

    def run(self):
        print "[+] Starting login process..."
        # Get homepage to set referer
        self.driver.get(self.login_url)
        if successful_load in self.driver.page_source :
            print '[+] Page load successful'
        else :
            print '[-] Page load not successful, possibly blocked'
        # Fill form fields
        try :
            # Enter Username
            username_field_selector = '//input[@placeholder="E-mail Address"]'
            self.wait_for_element_become_visible(username_field_selector)
            username_field = self.driver.find_element(By.XPATH, username_field_selector)
            username_field.send_keys(self.username)
            # Enter Password
            password_field = self.driver.find_element(By.XPATH, '//input[@placeholder="Password"]')
            for c in self.password :
                password_field.send_keys(c)
            # Click submit button
            submit = self.driver.find_element(By.XPATH, '//button[@aria-label="Log In"]')
            submit.click()
            time.sleep(15)
            if self.wait_for_text_in_page(successful_login) == None :
                 print '[-] Login failed'
            else :
                print '[+] Login successful'
        except (NoSuchElementException, ElementNotVisibleException) as ex :
            print "[-] Elements not found on page"
            print str(ex)
        except Exception as ex :
            print "[-] Unhandled error"
            print str(ex)

        # Create output dir if doesn't exist
        if not os.path.exists(os.path.dirname(self.imagename)) :
            try :
                if os.path.dirname(self.imagename) != '' :
                    os.makedirs(os.path.dirname(self.imagename))
            except OSError as exc: # Guard against race condition
                if exc.errno != errno.EEXIST:
                    raise
        # Wait for page to load
        self.screenshot()

    def check_exists_and_visible_by_xpath(self, xpath_selector):
        try :
            return self.driver.find_element_by_xpath(xpath_selector).is_displayed()
        except NoSuchElementException :
            return False
        return True

    def wait_for_element_become_visible(self, xpath_selector) :
        while not self.check_exists_and_visible_by_xpath(xpath_selector) :
            print "[+] Waiting for %s to become visible" % xpath_selector
            # Wait for login pop up to load via ajax
            time.sleep(1)
            self.timeout = self.timeout - 1
            if self.timeout == 0 :
                print "[-] Timed out %s" % xpath_selector
                self.screenshot()
                return None

    def wait_for_text_in_page(self, text) :
        printed = False
        while not successful_login in self.driver.page_source :
            if successful_load in self.driver.page_source :
                return None
            if not printed :
                print "[+] Waiting for text: %s to load in page" % text
                printed = True
            # Wait for login pop up to load via ajax
            time.sleep(1)
            self.timeout = self.timeout - 1
            if self.timeout == 0 :
                if not successful_load in self.driver.page_source :
                    print "[-] Possibly blocked"
                    return None
                print "[-] Timed out %s" % text
                return None
        return True

    def screenshot(self) :
        # Take screen shot of the page
        self.driver.save_screenshot(sys.path[0] + '/' + self.imagename)
        self.driver.get_screenshot_as_png()
        # Save html dump
        print "[+] Saving page to %s" % self.filename
        with open(sys.path[0] + '/' + self.filename, "w") as fout:
            fout.write(self.driver.page_source.encode("utf-8"))
            fout.flush()
        print "[+] Done."

if __name__ == '__main__' :
    display = Display(visible=0, size=(1280, 800))
    display.start()
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', action='store_true', default=False, dest='bruteforce_enabled')
    parser.add_argument('-c', action='store_true', default=False, dest='use_chrome')
    parser.add_argument('-f', action='store_true', default=False, dest='use_firefox')
    parser.add_argument('-s', action='store', default=False, dest='use_blink')
    args = parser.parse_args()
    use_chrome = args.use_chrome
    use_firefox = args.use_firefox
    use_blink = args.use_blink != None
    selected_browser = args.use_blink
    if use_chrome == False and use_firefox == False and use_blink == False :
        print 'Use -c or -f or -b [browser name] to choose driver (Chrome/Firefox/Blink)'
        exit(0)
    uagent = None
    out_dir = 'selenium_chrome_bf'
    if use_chrome :
        uagent = chrome_uagent
    elif use_firefox :
        uagent = ff_uagent
        out_dir = 'selenium_ff_bf'
    elif use_blink :
        out_dir = 'selenium_blink_bf'
    if not args.bruteforce_enabled :
        login = Login(username = username,
                      password = password,
                      referer = referer,
                      login_url = login_url,
                      origin = None,
                      uagent = uagent)
        login.run()
        login.clean_up()
    else :
        login = Login(username, password, referer, login_url, None, username)
        for i in range(1, 1001) :
            print '[%s] Sending Login Request...' % str(i)
            try :
                login.update_password(password + str(i))
                login.update_filename('./%s/%s.html' % (out_dir, str(i)))
                login.update_imagename('./%s/%s.png' % (out_dir, str(i)))
                login.run()
            except Exception as e :
                print e
        print 'Trying to login with correct credentials...'
        login.update_password(password)
        login.update_filename('./%s/login.html' % out_dir)
        login.update_imagename('./%s/login.png' % out_dir)
        login.run()
        print 'Done'
    display.stop()