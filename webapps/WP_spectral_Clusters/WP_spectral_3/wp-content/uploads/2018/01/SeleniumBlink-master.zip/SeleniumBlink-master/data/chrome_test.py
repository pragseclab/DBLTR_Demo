import time
from selenium import webdriver
from pyvirtualdisplay import Display


display = Display(visible = 0, size = (1920, 1080))
display.start()
options = webdriver.ChromeOptions()
options.add_argument("/home/blink/browsers/extensions/ups/")
options.binary_location = "/home/blink/browsers/chrome/opt/google/chrome/chrome"
driver = webdriver.Chrome(chrome_options = options)
driver.get("https://amiunique.org/fp")
time.sleep(10)
driver.save_screenshot('/home/blink/Downloads/result-chrome.png')
driver.get_screenshot_as_png()
with open('/home/blink/Downloads/result-chrome.html', "wb") as fout:
    fout.write(driver.page_source.encode("utf-8"))
    fout.flush()