#List of Ubuntu browsers
browsersList = ['FirefoxRepo','Firefox','Chrome','Chromium']
#browsersList = ['FirefoxRepo','Firefox','FirefoxESR','Chrome','Chromium','Opera']