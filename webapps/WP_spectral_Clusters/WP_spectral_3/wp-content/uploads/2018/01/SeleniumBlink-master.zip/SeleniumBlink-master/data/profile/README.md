This folder will contain the complete user profile that is used to transfer open tabs, bookmarks and paswwords between different browsing platforms.
