import time
from selenium import webdriver
from pyvirtualdisplay import Display


display = Display(visible = 0, size = (1920, 1080))
display.start()
options = webdriver.ChromeOptions()
options.add_argument("/home/blink/browsers/extensions/ups/")
options.binary_location = "/usr/bin/chromium-browser"
driver = webdriver.Chrome(chrome_options = options)
driver.get("https://amiunique.org/fp")
time.sleep(15)
driver.save_screenshot('/home/blink/Downloads/result-chromium.png')
driver.get_screenshot_as_png()
with open('/home/blink/Downloads/result-chromium.html', "wb") as fout:
    fout.write(driver.page_source.encode("utf-8"))
    fout.flush()