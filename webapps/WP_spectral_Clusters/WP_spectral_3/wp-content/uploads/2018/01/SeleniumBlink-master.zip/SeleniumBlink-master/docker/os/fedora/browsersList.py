#List of Fedora browsers
browsersList = ['FirefoxRepo','Firefox','Chrome','Chromium']
