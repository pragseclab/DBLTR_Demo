import time
from selenium import webdriver
from pyvirtualdisplay import Display
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary

#/usr/lib64/firefox/firefox -no-remote -setDefaultBrowser -profile /home/blink/.mozilla/firefox/blink.default
display = Display(visible = 0, size = (1920, 1080))
display.start()
profile = webdriver.FirefoxProfile("/home/blink/.mozilla/firefox/blink.default")
ffesr_binary = FirefoxBinary('/home/blink/browsers/firefox-latest/firefox')
driver = webdriver.Firefox(profile, firefox_binary=ffesr_binary)
driver.get("https://amiunique.org/fp")
time.sleep(15)
driver.save_screenshot('/home/blink/Downloads/result-firefox.png')
driver.get_screenshot_as_png()
with open('/home/blink/Downloads/result-firefox.html', "wb") as fout:
    fout.write(driver.page_source.encode("utf-8"))
    fout.flush()