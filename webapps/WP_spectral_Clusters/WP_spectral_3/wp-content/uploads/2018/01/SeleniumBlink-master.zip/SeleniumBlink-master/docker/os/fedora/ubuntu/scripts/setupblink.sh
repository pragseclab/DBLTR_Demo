#!/bin/bash
# Install docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update
sudo apt-get install -y docker-ce
sudo usermod -aG docker ${USER}

# Download Selenium Blink
sudo apt-get install -y unzip wget
wget https://www.silverf0x00.com/wp-content/uploads/2018/01/SeleniumBlink-master.zip
unzip SeleniumBlink-master.zip
cd SeleniumBlink-master
python3 installContainers.py